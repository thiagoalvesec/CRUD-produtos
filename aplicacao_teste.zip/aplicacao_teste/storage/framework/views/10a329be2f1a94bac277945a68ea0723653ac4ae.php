<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="col-sm-8 offset-sm-2">

        <h1 class="display-3"><?php echo e($title); ?></h1>
  
        
        <?php if($errors->form->any()): ?>
            <div>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->form->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messageError): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($messageError); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
            </div><br />
        <?php endif; ?>
            
            <?php
            
                if ($product->id) {
                    $formUrl = route('products.update', $product->id);
                    $formMethod = "PUT";
                    
                } else {
                    $formUrl = route('products.store');
                    $formMethod = "POST";
                }
            
            ?>
            
            <form method="POST" action="<?php echo e($formUrl); ?>">

                <?php echo method_field($product->id ? 'PUT' : 'POST'); ?>

                <?php echo csrf_field(); ?>

                <div class="form-group">    
                    <label for="name">Nome:</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $product->name)); ?>"  />
                </div>

                <div class="form-group">
                    <label for="categories">Escolha uma categoria:</label> <br>

                    <select class="form-control" name="category_id" id="categories" required__ >
                        <option value="">Selecione uma categoria</option>

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e($product->category_id == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                </div>

                
                <div class="form-group">
                    <label for="size_id">Escolha um tamanho</label>

                    <select class="form-control" name="size_id" id="Size" required____ >
                        <option value="">Selecione um tamanho</option>

                        <?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($Size->id); ?>" <?php echo e($product->size_id == $Size->id ? 'selected' : ''); ?>><?php echo e($Size->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>

                <div class="form-group">
                    <label for="color_id">Escolha uma cor</label>

                    <select class="form-control" name="color_id" id="Color">
                        <option value="">Selecione uma cor</option>

                        <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($Color->id); ?>" <?php echo e($product->color_id == $Color->id ? 'selected' : ''); ?>><?php echo e($Color->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>   

                    
                        
                </div>
                
                <div class="form-group">
                    <label for="price">Preço:</label>
                    <input type="text" class="form-control money" id="price" name="price" value="<?php echo e($product->price); ?>" required__/>
                </div>
                
                <div class="form-group">
                    <label for="amount">Quantidade:</label>
                    <input type="text" class="form-control" name="amount" value="<?php echo e($product->amount); ?>" required__ />
                </div>
                
                <div class="form-group">
                    <label for="description">Descrição:</label>
                    <input type="text" class="form-control" name="description" value="<?php echo e($product->description); ?>" required__ maxlength="35" minlength="10"/>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <?php echo e($product->id ? 'Atualizar produto' : 'Adicionar produto'); ?>

                </button>
                
            </form>
        </div>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/aplicacao_teste/resources/views/products/form.blade.php ENDPATH**/ ?>