<?php $__env->startSection('content'); ?>

	<h3>Produto</h3>

	<p><a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">Criar novo produto</a></p>

	<table class="table">

		<thead>
			<tr>
				<th>ID</th>
				<th>Categoria</th>
				<th>Nome</th>
				<th>Preço</th>
				<th>Qtde</th>
				<th>Descrição</th>
				<th>Data criação</th>
				<th>Data atualização</th>
				<th>Editar</th>
				<th>Deletar</th>
			</tr>
		</thead>
		
		<tbody>
				<tr>
					<td><?php echo e($product->id); ?></td>
					<td><?php echo e($product->category_id ? $product->category->name : '-'); ?></td>
					<td><?php echo e($product->name); ?></td>
					<td><?php echo e($product->price); ?></td>
					<td><?php echo e($product->amount); ?></td>
					<td><?php echo e($product->description); ?></td>
					<td><?php echo e($product->created_at); ?></td>
					<td><?php echo e($product->updated_at); ?></td>
					<td>
						<a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-primary">Editar</a>
						
					</td>
					<td>
						<form action="<?php echo e(route('products.delete', $product->id)); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>
							<button class="btn btn-danger" type="submit">Delete</button>
						</form>
					</td>
				</tr>
			
		</tbody>

	</table>

	<div class="col-sm-12">
		<?php if(session()->get('success')): ?>
		  <div class="alert alert-success">
			<?php echo e(session()->get('success')); ?>  
		  </div>
		<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/aplicacao_teste/resources/views/products/product.blade.php ENDPATH**/ ?>