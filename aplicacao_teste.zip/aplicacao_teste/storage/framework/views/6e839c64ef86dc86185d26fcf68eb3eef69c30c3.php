<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="col-sm-8 offset-sm-2">

        <h1 class="display-3"><?php echo e($title); ?></h1>

        <div>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div><br />
            <?php endif; ?>
            
            <?php
            
                if ($category->id) {
                    $formUrl = url('categories/'.$category->id.'/update');
                    $formMethod = "PUT";
                    
                } else {
                    $formUrl = url('categories');
                    $formMethod = "POST";
                }
            
            ?>
            
            <form method="POST" action="<?php echo e($formUrl); ?>">

                <?php echo method_field($category->id ? 'PUT' : 'POST'); ?>

                <?php echo csrf_field(); ?>

                <div class="form-group">    
                    <label for="name">Nome:</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($category->name); ?>" required__/>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <?php echo e($category->id ? 'Atualizar categoria' : 'Adicionar categoria'); ?>

                </button>
                
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/aplicacao_teste/resources/views/categories/form.blade.php ENDPATH**/ ?>