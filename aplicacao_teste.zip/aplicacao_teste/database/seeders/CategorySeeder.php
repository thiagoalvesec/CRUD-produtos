<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $categories = [
            ["id" => 1, "name" => "Blusa"],
            ["id" => 2, "name" => "Calça"],
            ["id" => 3, "name" => "Short"],
            ["id" => 4, "name" => "Camiseta"],
            ["id" => 5, "name" => "Acessório"],
            ["id" => 6, "name" => "Roupa íntima"],
        ];

        Category::truncate();
        Category::insert($categories);
    }
}
