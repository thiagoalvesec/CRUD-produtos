<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//HOMEPAGE

Route::get('/', function () {
    return view('welcome');
});


// PRODUCTS PAGES

// Route::resource('products', "ProductController");

// read products' list
Route::get("products", "ProductController@index");

// create new product and store it at database
Route::get('products/create', "ProductController@create")->name("products.create");
Route::post("products", "ProductController@store")->name("products.store");

// consult product by id
Route::get('products/{id}/show', "ProductController@show");

// edit one product's field by id
Route::get('products/{id}/edit', "ProductController@edit")->name("products.edit");

// update product by id
Route::put('products/{id}/update', "ProductController@update")->name("products.update");

// delete product by id
Route::delete('products/{id}/delete', "ProductController@destroy")->name("products.delete");




// CATEGORIES PAGES

Route::get("categories", "CategoryController@index");

Route::get('categories/create', "CategoryController@create");
Route::post('categories', "CategoryController@store");

Route::get('categories/{id}/show', "CategoryController@show");

Route::get('categories/{id}/edit', "CategoryController@edit")->name("categories.edit");

Route::put('categories/{id}/update', "CategoryController@update")->name("categories.update");

Route::delete('categories/{id}/delete', "CategoryController@destroy")->name("categories.delete");