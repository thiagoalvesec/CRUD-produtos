<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'price',
        'amount',
        'description',
        'category_id',
        'size_id',
        'color_id',
    ];

    /**
     * Obter categoria do produto
     *
     * @return void
     */
    public function category() {
        return $this->belongsTo('App\Models\Category', 'category_id');
    }

    /**
     * Obter tamanho do produto
     *
     * @return void
     */
    public function Size() {
        return $this->belongsTo('App\Models\Size', 'size_id');
    }

    /**
     * Obter color do produto
     *
     * @return void
     */
    public function Color() {
        return $this->belongsTo('App\Models\Color', 'color_id');
    }
}
