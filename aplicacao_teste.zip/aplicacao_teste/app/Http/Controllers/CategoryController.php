<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Color;
use App\Models\Size;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $product = new Product();
        $categories = Category::all();

        // foreach ($categories as $category) {
        //     $categoryProducts = $category->products;
        //     // dd($categoryProducts);
        // }
        
        $data = [
            "product" => $product,
            "categories" => $categories,
            "title" => "Lista de categorias",
        ];

        return view('categories.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $category = new Category();
        $product = new Product();
        $size = Size::all();
        $color = Color::all();

        $data = [
            'product' => $product,
            'category' => $category,
            'size_id' => $product->size_id,
            'color_id' => $product->color_id,
            'size' => $size,
            'color' => $color,
            'title' => 'Crie uma nova categoria'
        ];

        return view('categories.form', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validation($request);

        if(!$validator->fails()){

            $category = new Category([
                'name' => $request->get('name')
            ]);

            $category->save();

            return redirect('/categories')->with('success', 'Categoria salva!');

        } else {
            return back()->withErrors($validator);
        }

        


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return view('categories.category',[
            'category' => Category::findOrFail($id)
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $category = Category::find($id);


        $data = [
            'category' => $category,
            'title' => 'Edite esse produto',
        ];

        return view('categories.form', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validation($request);

        if(!$validator->fails()){
            
            $category = Category::find($id);
            $category->name = $request->get('name');
            $category->save();
    
            return redirect('/categories')->with('success', 'Categoria atualizada!');

        } else {
            //dd($validator->errors());
            return back()->withErrors($validator);
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $category = Category::find($id);
        $category->delete();

        return redirect('/categories')->with('success', 'Categoria removida!');
    }

     /**
     * Realizar validação do formulário
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Validation\Validator
     */
    private function validation(Request $request){

        $data = $request->all();

        $rules = [
            'name' => 'bail|required|string|alpha|max:30|min:6',
        ];

        $messages = [
            'name.min' => 'O campo nome está muito pequeno',
            'name.max' => 'O campo nome está muito grande',
        ];

        $customAttributes = [
            'name' => 'nome', // Atributo de name para nome na view
        ];

        $validator = Validator::make($data, $rules, $messages, $customAttributes);

        return $validator;
    }
}

