
@extends('templates.default')

@section('content')

	<h3>Categoria</h3>

	<p><a href="{{ url('categories/create') }}" class="btn btn-primary">Criar nova categoria</a></p>

	<table class="table">

		<thead>
			<tr>
				<th>ID</th>
				<th>Nome</th>
				<th>Editar</th>
				<th>Deletar</th>
			</tr>
		</thead>
		
		<tbody>
				<tr>
					<td>{{ $category->id }}</td>
					<td>{{ $category->name }}</td>
					<td>
						<a href="{{ url('categories/'.$category->id.'/edit') }}" class="btn btn-primary">Editar</a>
					</td>
					<td>
						<form action="{{ url("categories/{$category->id}/delete") }}" method="POST">
							@csrf
							@method('DELETE')
							<button class="btn btn-danger" type="submit">Delete</button>
						</form>
					</td>
				</tr>
		</tbody>

	</table>

	<div class="col-sm-12">
		@if(session()->get('success'))
		  <div class="alert alert-success">
			{{ session()->get('success') }}  
		  </div>
		@endif
	</div>





@endsection