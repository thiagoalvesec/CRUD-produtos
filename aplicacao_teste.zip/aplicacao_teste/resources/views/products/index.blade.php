
@extends('templates.default')

@section('content')

	<h3>{{ $title }}</h3>

	<p><a href="{{ route('products.create') }}" class="btn btn-primary">Criar novo produto</a></p>

	<table class="table">

		<thead>
			<tr>
				<th>ID</th>
				<th>Categoria</th>
				<th>Tamanho</th>
				<th>Cor</th>
				<th>Nome</th>
				<th>Preço</th>
				<th>Qtde</th>
				<th>Descrição</th>
				<th>Data criação</th>
				<th>Data atualização</th>
				<th>Editar</th>
				<th>Deletar</th>
			</tr>
		</thead>
		
		<tbody>
			@foreach ($products as $product)
				<tr>
					<td>{{ $product->id }}</td>
					<td>{{ $product->category->name}}</td>
					{{-- <td>{{ $product->size_id ? $product->Size->name: '-'}}</td> --}}
					<td>{{ $product->size_id ? $product->Size->name: '-'}}</td>
					<td>{{ $product->Color->name}}</td>
					<td>{{ $product->name }}</td>
					<td>{{ $product->price}}</td>
					<td>{{ $product->amount}}</td>
					<td>{{ $product->description }}</td>
					<td>{{ $product->created_at }}</td>
					<td>{{ $product->updated_at }}</td>
					<td>
						<a href="{{ route('products.edit', $product->id)}}" class="btn btn-primary">Editar</a>
						{{-- <form action="{{ route('products.edit', $product->id) }}" method="GET">
							@csrf
							<button class="btn btn-primary" type="submit">Edit</button>
						</form> --}}
					</td>
					<td>
						<form action="{{ route('products.delete', $product->id) }}" method="POST">
							@csrf
							@method('DELETE')
							<button class="btn btn-danger" type="submit">Delete</button>
						</form>
					</td>
				</tr>

			@endforeach
			
		</tbody>

	</table>

	<div class="col-sm-12">
		@if(session()->get('success'))
		  <div class="alert alert-success">
			{{ session()->get('success') }}  
		  </div>
		@endif
	</div>
@endsection